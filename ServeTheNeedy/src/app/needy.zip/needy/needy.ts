export class Needy {
    id: number;
    username: string;
    password: string;
    constructor(){
       
    }
}
