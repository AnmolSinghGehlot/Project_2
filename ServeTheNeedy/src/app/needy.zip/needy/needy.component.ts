import { Component, OnInit } from '@angular/core';
import { DonationService } from './donation.service';
import { HttpClientModule } from '@angular/common/http';

@Component({
  selector: 'app-needy',
  templateUrl: './needy.component.html',
  styleUrls: ['./needy.component.css']
})


export class NeedyComponent  {
  

  
}
