import { Needy } from './needy';

describe('Needy', () => {
  it('should create an instance', () => {
    expect(new Needy()).toBeTruthy();
  });
});
